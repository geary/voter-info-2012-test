// Copyright 2010 Michael Geary
// http://mg.to/
// Free Beer and Free Speech License (any OSI license)
// http://freebeerfreespeech.org/

document.write(
	'<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery', opt.debug ? '' : '.min', '.js">',
	'</script>'
);

opt.writeScript( 'voter-info-iraq.js' );
